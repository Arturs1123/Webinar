module.exports = async function (Repository, logger) {
    const useCase = new Map()

    return useCase
}
