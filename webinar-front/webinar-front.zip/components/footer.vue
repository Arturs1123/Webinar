<template>
  <div>
    made by Kostrov Studio
  </div>
</template>

<script>
export default {
  name: "Footer"
}
</script>

<style scoped>

</style>
