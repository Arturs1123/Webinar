<template>

</template>

<script>
export default {
  name: "banWord"
}
</script>

<style scoped>

</style>
