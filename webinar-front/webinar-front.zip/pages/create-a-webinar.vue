<template>
  <CreateWebinarForm/>
</template>
