<template>
  <Room/>
</template>
